#
import pygame #
import sys #
import random #
import math #

import time #
import smtplib #
from email.mime.text import MIMEText #
import os  # 

pygame.init() #

pygame.mixer.init() #

#colors - Isaac T-S 
BLACK = (000,000,000)
BLUE = (000,000,255)
YELLOW = (255,255,000)
WHITE = (255,255,255)
RED = (255,000,000)
PINK = (255,192,203)
CYAN = (000,255,255)
ORANGE = (255,165,000)
GREEN = (30, 122, 000)
GOLD = (252, 186, 3)
GRAY = (177,177,177)

# 
playing_music = pygame.mixer.Sound('playing_music.mp3')  # 
question_music = pygame.mixer.Sound('question_music.mp3')  # 
game_over_music = pygame.mixer.Sound('game_over_music.mp3')  # 

#
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 650
CELL_SIZE = 40

#
GRID_WIDTH = 15
GRID_HEIGHT = 15

#Game states - Isaac T-S
PLAYING = 0
GAME_OVER = 1
QUESTION = 2
RESUME = 3
GAME_WIN = 4

game_state = PLAYING #Global game state

MUSIC_LOOP_START = 0 #
PLAYING_MUSIC_LOOP = 1 #
QUESTION_MUSIC_LOOP = 2 #
GAME_OVER_MUSIC_LOOP = 3 #

music_loop = MUSIC_LOOP_START #

question_loop = 1

# 
LIVES = 3 

#Screen Settings
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Zero-Day")

#Score font
font = pygame.font.Font(None, 36)

#Gides / Game Maps

#Defult test map
grid1= [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,1,0,0,0,0,0,0,1],
    [1,0,1,0,1,1,0,1,0,1,0,1,1,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,1,1,0,1,1,1,1,1,0,1,1,0,1],
    [1,0,0,0,0,0,0,1,0,0,0,0,0,0,1],
    [1,1,1,1,0,1,0,1,0,1,0,1,1,1,1],
    [1,1,1,1,0,1,0,0,0,1,0,1,1,1,1],
    [1,1,1,1,0,1,0,1,0,1,0,1,1,1,1],
    [1,0,0,0,0,0,0,1,0,0,0,0,0,0,1],
    [1,0,1,1,0,1,1,1,1,1,0,1,1,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,1,1,0,1,0,1,0,1,0,1,1,0,1],
    [1,0,0,0,0,0,0,1,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    ]

#Player Avatar
WH_hacker = {
    'x': 1,
    'y': 1,
    'direction': 3, # 0=right 1=down 2=left 3=up - Issac T-S
    }

#Black hat hackers 
BH_hackers = [
    {'x': 1, 'y': 13, 'color': RED}, #hacker 1
    {'x': 13, 'y': 1, 'color': PINK}, #hacker 2
    {'x': 13, 'y': 13, 'color': CYAN}, #hacker 3
    {'x': 11, 'y': 11, 'color': ORANGE} #hacker 4
]

#Score
score = 0

#Game Loop
clock = pygame.time.Clock() #limites frames per seconed 
running = True # used as a flag and to saee if the game should be running

#Movment delays
#time mesuredf in miliseconeds 
WH_hacker_move_delay = 150 # player movment rate
BH_move_delay = 300 # enemy momvment rate 
#time musermentsin milisecrtioneds 
last_WH_hacker_move_time = 0 # time sinces last player movment
last_BH_move_time = 0 # time sinces last enemy movment

#
def move_WH_hacker():
    global score #calls score from global
    #moivment
    dx,dy = [(1,0),(0,1),(-1,0),(0,-1)] [WH_hacker['direction']] #direction thay moving
    new_x, new_y = WH_hacker["x"] + dx, WH_hacker['y'] +dy # new postion = player postion + direction 
    #postion checking
    if grid1[new_y][new_x]!= 1: #checks if a spaces isnt 1 and if not runs if statment
        WH_hacker['x'],WH_hacker['y'] = new_x, new_y #alows movment to non 1 cells 
        if grid1[new_y][new_x]==0: # checks if spaces is etean if not runs if statment
            grid1[new_y][new_x]= 2 # changes postion to eaten 
            score +=10 #adds ten to the score
      
#
def move_BH(BH):
    directions = [(1,0),(0,1),(-1,0),(0,-1)] # difinese diraction
    random.shuffle(directions) # poicks one of the directions randomely
    for dx, dy in directions: # what to do for dx, dy in directiones, loop starts
        new_x, new_y = BH["x"] + dx, BH['y'] +dy # new postion = enemy postion + direction 
        if 0 <= new_x < GRID_WIDTH and 0 <= new_y < GRID_HEIGHT and grid1[new_y][new_x] != 1: # proventes enemys leving the grid
            BH['x'], BH['y'] = new_x, new_y # moves enemy to new postion 
            break # stops loop
        
        #player sprite CHANGE LATTER
def draw_WH_hacker():
    x = WH_hacker['x'] * CELL_SIZE + CELL_SIZE // 2
    y = WH_hacker['y'] * CELL_SIZE + CELL_SIZE // 2 + 50

    # Draw Player as a circle
    #x=-left/+right, y=-up/+down, width ,hight
    pygame.draw.rect(screen, GRAY, (x-11, y-7, 20, 20)) # body
    #left eye
    pygame.draw.rect(screen, WHITE, (x-14, y+1, 10, 5)) # white 
    pygame.draw.rect(screen, BLACK, (x-11, y+1, 5, 5)) # iris
    #right eye
    pygame.draw.rect(screen, WHITE, (x+1, y+1, 10, 5)) # white
    pygame.draw.rect(screen, BLACK, (x+3, y+1, 5, 5)) # iris    
    #hat
    pygame.draw.rect(screen, WHITE, (x-16, y-7, 30, 7)) #hat rim 
    pygame.draw.rect(screen, WHITE, (x-11, y-15, 20, 10)) # hat top 
    pygame.draw.rect(screen, BLACK, (x-16, y-5, 30, 2)) #hat strap
    
# Temp enemy sprite 
def draw_BH(BH):
    x = BH['x'] * CELL_SIZE + CELL_SIZE // 2
    y = BH['y'] * CELL_SIZE + CELL_SIZE // 2 + 50 #postion of sprite and centering of sprite
    
    #x=-left/+right, y=-up/+down, width ,hight
    pygame.draw.rect(screen, GRAY, (x-11, y-7, 20, 20)) # body
    #left eye
    pygame.draw.rect(screen, WHITE, (x-14, y+1, 10, 5)) # white 
    pygame.draw.rect(screen, BLACK, (x-11, y+1, 5, 5)) # iris
    #right eye
    pygame.draw.rect(screen, WHITE, (x+1, y+1, 10, 5)) # white
    pygame.draw.rect(screen, BLACK, (x+3, y+1, 5, 5)) # iris    
    #hat
    pygame.draw.rect(screen, BLACK, (x-16, y-7, 30, 7)) #hat rim 
    pygame.draw.rect(screen, BLACK, (x-11, y-15, 20, 10)) # hat top
    pygame.draw.rect(screen, BH['color'], (x-16, y-5, 30, 2)) #hat strap
      
def play_music(state): #
    global music_loop #
    
    if state == PLAYING: #
        if music_loop != PLAYING_MUSIC_LOOP: #
            pygame.mixer.stop() #
            playing_music.play(-1)  # 
            music_loop = PLAYING_MUSIC_LOOP #

    elif state == QUESTION: #
        if music_loop != QUESTION_MUSIC_LOOP: #
               pygame.mixer.stop() #
               question_music.play(-1)  # 
               music_loop = QUESTION_MUSIC_LOOP #

    elif state == GAME_OVER: #
        if music_loop != GAME_OVER_MUSIC_LOOP: #
               pygame.mixer.stop() #
               game_over_music.play(-1)  # 
               music_loop = GAME_OVER_MUSIC_LOOP #

def resume_game():
    #
    global WH_hacker, BH_hackers, game_state, question_loop, email_receiver
    #Player Avatar
    WH_hacker = {
    'x': 1,
    'y': 1,
    'direction': 3, # 0=right 1=down 2=left 3=up - Issac T-S
    }
    #
    BH_hackers = [ #Black hat hackers
        {'x': 8, 'y': 8, 'color': RED}, #hacker 1
        {'x': 8, 'y': 8, 'color': PINK}, #hacker 2
        {'x': 8, 'y': 8, 'color': CYAN}, #hacker 3
        {'x': 8, 'y': 8, 'color': ORANGE} #hacker 4
    ]
    #
    game_state = PLAYING

    question_loop = 1
    
    email_receiver = ""
    
#rest conditions
def reset_game():
    #
    global WH_hacker, BH_hackers, score, LIVES, grid1, game_state, question_loop, email_receiver
    #
    WH_hacker = { # White hat hackers
        'x': 1,
        'y': 1,
        'direction': 3, # 0=right 1=down 2=left 3=up - Issac T-S 
    }
    #
    BH_hackers = [ #Black hat hackers
        {'x': 1, 'y': 13, 'color': RED}, #hacker 1
        {'x': 13, 'y': 1, 'color': PINK}, #hacker 2
        {'x': 13, 'y': 13, 'color': CYAN}, #hacker 3
        {'x': 11, 'y': 11, 'color': ORANGE} #hacker 4
    ]
    #Score
    score = 0
    #
    LIVES = 3
    #
    question_loop = 1
    #
    grid1= [ #deflut testing grid
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],#15
    [1,0,0,0,0,0,0,1,0,0,0,0,0,0,1],#14
    [1,0,1,0,1,1,0,1,0,1,0,1,1,0,1],#13
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],#12
    [1,0,1,1,0,1,1,1,1,1,0,1,1,0,1],#11
    [1,0,0,0,0,0,0,1,0,0,0,0,0,0,1],#10
    [1,1,1,1,0,1,0,1,0,1,0,1,1,1,1],#9
    [1,1,1,1,0,1,0,0,0,1,0,1,1,1,1],#8
    [1,1,1,1,0,1,0,1,0,1,0,1,1,1,1],#7
    [1,0,0,0,0,0,0,1,0,0,0,0,0,0,1],#6
    [1,0,1,1,0,1,1,1,1,1,0,1,1,0,1],#5
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],#4
    [1,0,1,1,0,1,0,1,0,1,0,1,1,0,1],#3
    [1,0,0,0,0,0,0,1,0,0,0,0,0,0,1],#2
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],#1
    ]
    #1,2,3,4,5,6,7,8,9,0,1,2,3,4,5
    
    #
    game_state = PLAYING
    
    email_receiver = ""

def send_email (): # Email code
    global score, email_receiver
   
    email_sender = "hackman.scores@gmail.com" #

    app_password = "rgbh fwgl mzrr rjjc"  # 

    #
    email_subject = " YOUR FINAL SCORE!" #
    email_body = f"Your final score is {score}!!! Thanks for playing!" # 
    msg = MIMEText(email_body) #
    msg['Subject'] = email_subject #
    msg['From'] = email_sender #
    msg['To'] = email_receiver #

    try: #
        # 
        with smtplib.SMTP('smtp.gmail.com', 587) as server: #
            server.starttls()  # 
            server.login(email_sender, app_password)  # 
            server.sendmail(email_sender, email_receiver, msg.as_string())  # 
            print("Email Code Ran Successfully") #
    except Exception as e: # 
        print(f" Email code failed: {e}") #
    

#Question screen
def draw_question_test():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 64)
    question_font = pygame.font.Font(None, 36)
    answers_font = pygame.font.Font(None, 36)
    #
    title_text = title_font.render("Question Type: Test", True, GREEN)
    question_text = question_font.render("Qestion: Press a to be corect...", True, GREEN)
    answer_text_W = answers_font.render("W: Wrong" , True, GREEN)
    answer_text_A = answers_font.render("A: Correct", True, GREEN)
    answer_text_S = answers_font.render("D: Wrong", True, GREEN)
    answer_text_D = answers_font.render("S: Wrong", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.5 - title_text.get_width() * 0.5, SCREEN_HEIGHT * 0.10))
    screen.blit(question_text, (SCREEN_WIDTH * 0.5 - question_text.get_width() * 0.5, SCREEN_HEIGHT * 0.20))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.20 - answer_text_W.get_width() * 0.5, SCREEN_HEIGHT * 0.30))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.20 - answer_text_A.get_width() * 0.5, SCREEN_HEIGHT * 0.50))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.20 - answer_text_S.get_width() * 0.5, SCREEN_HEIGHT * 0.70))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.20 - answer_text_D.get_width() * 0.5, SCREEN_HEIGHT * 0.90))
  
def draw_question1():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: General Knowledge", True, GREEN)
    question_text = question_font.render("Qestion: What does the acronym CIA  ", True, GREEN)
    question_text1 = question_font.render("stand for in cybersecurity?", True, GREEN)
    answer_text_W = answers_font.render("W: Confidentiality, Integrity, Availability" , True, GREEN)
    answer_text_W1 = answers_font.render("" , True, GREEN)
    answer_text_A = answers_font.render("A: Cybersecurity, Information, Access", True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S = answers_font.render("D: Computers, Internet, Authentication", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D = answers_font.render("S: Confidentiality, Identification, ", True, GREEN)
    answer_text_D1 = answers_font.render("Authorization", True, GREEN)  
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
    
#Question screen
def draw_question2():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: General Knowledge", True, GREEN)
    question_text = question_font.render("Qestion: What is a firewall?", True, GREEN)
    question_text1 = question_font.render("", True, GREEN)
    answer_text_W = answers_font.render("W: A security system that monitors and controls " , True, GREEN)
    answer_text_A = answers_font.render("A: A tool to clean viruses from your computer", True, GREEN)
    answer_text_S = answers_font.render("D: Software that blocks access to all websites", True, GREEN)
    answer_text_D = answers_font.render("S: A device that cools down overheated servers", True, GREEN)
    answer_text_W1 = answers_font.render("incoming and outgoing network traffic" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question3():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: General Knowledge", True, GREEN)
    question_text = question_font.render("Qestion: What is the main goal of ", True, GREEN)
    question_text1 = question_font.render("encryption?", True, GREEN)
    answer_text_W = answers_font.render("W: To protect data by making it unreadable to " , True, GREEN)
    answer_text_A = answers_font.render("A: To increase internet speed", True, GREEN)
    answer_text_S = answers_font.render("D: To back up data to the cloud", True, GREEN)
    answer_text_D = answers_font.render("S: To store data in plain text", True, GREEN)
    answer_text_W1 = answers_font.render("unauthorized users" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question4():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: General Knowledge", True, GREEN)
    question_text = question_font.render("Qestion: What is multi-factor ", True, GREEN)
    question_text1 = question_font.render("authentication (MFA)?", True, GREEN)
    answer_text_W = answers_font.render("W: A security system requiring multiple verification " , True, GREEN)
    answer_text_A = answers_font.render("A: A system that locks users out after one failed ", True, GREEN)
    answer_text_S = answers_font.render("D: A tool to manage multiple accounts at once", True, GREEN)
    answer_text_D = answers_font.render("S: A method to bypass password requirements", True, GREEN)
    answer_text_W1 = answers_font.render("methods to access a system" , True, GREEN)
    answer_text_A1 = answers_font.render("attempt", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question5():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: General Knowledge", True, GREEN)
    question_text = question_font.render("Qestion: What is the purpose of a VPN?", True, GREEN)
    question_text1 = question_font.render("", True, GREEN)
    answer_text_W = answers_font.render("W: To create a secure connection over a public network" , True, GREEN)
    answer_text_A = answers_font.render("A: To block advertisements on websites", True, GREEN)
    answer_text_S = answers_font.render("D: To increase the speed of internet connections", True, GREEN)
    answer_text_D = answers_font.render("S: To provide free access to premium services", True, GREEN)
    answer_text_W1 = answers_font.render("" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question6():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Phishing", True, GREEN)
    question_text = question_font.render("Qestion: What is phishing?", True, GREEN)
    question_text1 = question_font.render("", True, GREEN)
    answer_text_W = answers_font.render("W: A fraudulent attempt to obtain sensitive information " , True, GREEN)
    answer_text_A = answers_font.render("A: A technique for identifying fake software", True, GREEN)
    answer_text_S = answers_font.render("D: A method to optimize network performance", True, GREEN)
    answer_text_D = answers_font.render("S: A way to protect data from malware", True, GREEN)
    answer_text_W1 = answers_font.render("by pretending to be a trustworthy entity" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question7():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Phishing", True, GREEN)
    question_text = question_font.render("Qestion: What is a common sign of a ", True, GREEN)
    question_text1 = question_font.render("phishing email?", True, GREEN)
    answer_text_W = answers_font.render("W: Suspicious links or requests for sensitive " , True, GREEN)
    answer_text_A = answers_font.render("A: Offers of free software downloads", True, GREEN)
    answer_text_S = answers_font.render("D: Emails without any spelling errors", True, GREEN)
    answer_text_D = answers_font.render("S: A subject line that includes your full name", True, GREEN)
    answer_text_W1 = answers_font.render("information" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question8():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Phishing", True, GREEN)
    question_text = question_font.render("Qestion: How can you verify the ", True, GREEN)
    question_text1 = question_font.render("legitimacy of an email sender?", True, GREEN)
    answer_text_W = answers_font.render("W: Check the email address carefully and hover over " , True, GREEN)
    answer_text_A = answers_font.render("A: Reply to the email asking for clarification", True, GREEN)
    answer_text_S = answers_font.render("D: Assume the email is safe if it includes a company ", True, GREEN)
    answer_text_D = answers_font.render("S: Open the attachment to see if it contains ", True, GREEN)
    answer_text_W1 = answers_font.render("links to inspect URLs" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("logo", True, GREEN)
    answer_text_D1 = answers_font.render("legitimate content", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question9():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Phishing", True, GREEN)
    question_text = question_font.render("Qestion: What should you do if you ", True, GREEN)
    question_text1 = question_font.render("suspect an email is phishing?", True, GREEN)
    answer_text_W = answers_font.render("W: Do not click on links or attachments and report the " , True, GREEN)
    answer_text_A = answers_font.render("A: Forward it to your friends for their opinion", True, GREEN)
    answer_text_S = answers_font.render("D: Reply asking for more information", True, GREEN)
    answer_text_D = answers_font.render("S: Open the attachment to confirm its authenticity", True, GREEN)
    answer_text_W1 = answers_font.render("email" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question10():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Phishing", True, GREEN)
    question_text = question_font.render("Qestion: What is spear phishing?", True, GREEN)
    question_text1 = question_font.render("", True, GREEN)
    answer_text_W = answers_font.render("W: A targeted phishing attack aimed at a specific " , True, GREEN)
    answer_text_A = answers_font.render("A: A phishing attack that spreads through social ", True, GREEN)
    answer_text_S = answers_font.render("D: A type of scam involving fake lottery winnings", True, GREEN)
    answer_text_D = answers_font.render("S: A random email blast to multiple recipients", True, GREEN)
    answer_text_W1 = answers_font.render("individual or organization" , True, GREEN)
    answer_text_A1 = answers_font.render("media platforms", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question11():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Passwords", True, GREEN)
    question_text = question_font.render("Qestion: What makes a strong password?", True, GREEN)
    question_text1 = question_font.render("", True, GREEN)
    answer_text_W = answers_font.render("W: At least 12 characters, a mix of letters, numbers, " , True, GREEN)
    answer_text_A = answers_font.render("A: Your full name and birthdate", True, GREEN)
    answer_text_S = answers_font.render("D: A short phrase with no special characters", True, GREEN)
    answer_text_D = answers_font.render("S: Repeating the same character multiple times", True, GREEN)
    answer_text_W1 = answers_font.render("and special symbols" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question12():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Passwords", True, GREEN)
    question_text = question_font.render("Qestion: Why is it risky to reuse  ", True, GREEN)
    question_text1 = question_font.render("passwords across multiple accounts?", True, GREEN)
    answer_text_W = answers_font.render("W:  If one account is compromised, all accounts with " , True, GREEN)
    answer_text_A = answers_font.render("A: It slows down your internet connection", True, GREEN)
    answer_text_S = answers_font.render("D: It increases the likelihood of forgetting your ", True, GREEN)
    answer_text_D = answers_font.render("S: It causes software to malfunction", True, GREEN)
    answer_text_W1 = answers_font.render("the same password are at risk" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("passwords", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question13():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Passwords", True, GREEN)
    question_text = question_font.render("Qestion: What is the purpose of a  ", True, GREEN)
    question_text1 = question_font.render("password manager?", True, GREEN)
    answer_text_W = answers_font.render("W: To securely store and manage passwords for " , True, GREEN)
    answer_text_A = answers_font.render("A: To automatically generate email addresses", True, GREEN)
    answer_text_S = answers_font.render("D: To log in to accounts without a password", True, GREEN)
    answer_text_D = answers_font.render("S: To monitor internet browsing habits", True, GREEN)
    answer_text_W1 = answers_font.render("multiple accounts" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question14():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Passwords", True, GREEN)
    question_text = question_font.render("Qestion: What is the principle of  ", True, GREEN)
    question_text1 = question_font.render("least privilege?", True, GREEN)
    answer_text_W = answers_font.render("W: Users should only have access to the " , True, GREEN)
    answer_text_A = answers_font.render("A: Granting everyone full access to ", True, GREEN)
    answer_text_S = answers_font.render("D: Setting up multiple administrator ", True, GREEN)
    answer_text_D = answers_font.render("S: Limiting access to only the IT ", True, GREEN)
    answer_text_W1 = answers_font.render("resources necessary for their role" , True, GREEN)
    answer_text_A1 = answers_font.render("all resources", True, GREEN)
    answer_text_S1 = answers_font.render("accounts", True, GREEN)
    answer_text_D1 = answers_font.render("department", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question15():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Passwords", True, GREEN)
    question_text = question_font.render("Qestion: Why should you avoid using  ", True, GREEN)
    question_text1 = question_font.render("personal information in your passwords?", True, GREEN)
    answer_text_W = answers_font.render("W: It can be easily guessed by attackers using " , True, GREEN)
    answer_text_A = answers_font.render("A: It makes your password too long", True, GREEN)
    answer_text_S = answers_font.render("D: It violates website terms of service", True, GREEN)
    answer_text_D = answers_font.render("S: It cannot be saved by password managers", True, GREEN)
    answer_text_W1 = answers_font.render("publicly available information" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question16():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Malware", True, GREEN)
    question_text = question_font.render("Qestion: What is malware?", True, GREEN)
    question_text1 = question_font.render("", True, GREEN)
    answer_text_W = answers_font.render("W: Malicious software designed to harm, exploit, " , True, GREEN)
    answer_text_A = answers_font.render("A: Software designed to enhance gaming performance", True, GREEN)
    answer_text_S = answers_font.render("D: A tool to block websites", True, GREEN)
    answer_text_D = answers_font.render("S: A program that boosts internet speed", True, GREEN)
    answer_text_W1 = answers_font.render("or otherwise compromise a system" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question17():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Malware", True, GREEN)
    question_text = question_font.render("Qestion: What is ransomware?", True, GREEN)
    question_text1 = question_font.render("", True, GREEN)
    answer_text_W = answers_font.render("W: A type of malware that locks or encrypts files" , True, GREEN)
    answer_text_A = answers_font.render("A: A program used to recover deleted files", True, GREEN)
    answer_text_S = answers_font.render("D: A tool for creating secure backups", True, GREEN)
    answer_text_D = answers_font.render("S: A game application disguised as a virus", True, GREEN)
    answer_text_W1 = answers_font.render(" and demands payment for their release" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question18():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Malware", True, GREEN)
    question_text = question_font.render("Qestion: What is the difference ", True, GREEN)
    question_text1 = question_font.render("between a virus and a worm?", True, GREEN)
    answer_text_W = answers_font.render("W: A virus requires a host file to spread, while a " , True, GREEN)
    answer_text_A = answers_font.render("A: A virus is harmless, while a worm is dangerous", True, GREEN)
    answer_text_S = answers_font.render("D: A virus is an email attachment, while a worm ", True, GREEN)
    answer_text_D = answers_font.render("S: A virus spreads through websites, while a worm", True, GREEN)
    answer_text_W1 = answers_font.render("worm can self-replicate and spread independently" , True, GREEN)
    answer_text_A1 = answers_font.render("is a pop-up ad", True, GREEN)
    answer_text_S1 = answers_font.render("spreads through emails", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question19():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Malware", True, GREEN)
    question_text = question_font.render("Qestion: What is a trojan horse in ?", True, GREEN)
    question_text1 = question_font.render("cybersecurity", True, GREEN)
    answer_text_W = answers_font.render("W: A type of malware disguised as legitimate software " , True, GREEN)
    answer_text_A = answers_font.render("A: A security tool to protect online transactions", True, GREEN)
    answer_text_S = answers_font.render("D: A virus that only targets gaming systems", True, GREEN)
    answer_text_D = answers_font.render("S: A program that speeds up system performance", True, GREEN)
    answer_text_W1 = answers_font.render("to trick users into installing it" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
        
#Question screen
def draw_question20():
    #
    screen.fill(BLACK)
    #
    title_font = pygame.font.Font(None, 45)
    question_font = pygame.font.Font(None, 40)
    answers_font = pygame.font.Font(None, 30)
    #
    title_text = title_font.render("Question Type: Malware", True, GREEN)
    question_text = question_font.render("Qestion: How can you protect your ", True, GREEN)
    question_text1 = question_font.render("system from malware?", True, GREEN)
    answer_text_W = answers_font.render("W: Use antivirus software, keep systems updated, " , True, GREEN)
    answer_text_A = answers_font.render("A: Only use a public Wi-Fi network", True, GREEN)
    answer_text_S = answers_font.render("D: Disable your antivirus for faster system ", True, GREEN)
    answer_text_D = answers_font.render("S: Only open attachments from unknown senders", True, GREEN)
    answer_text_W1 = answers_font.render("and avoid downloading files from untrusted sources" , True, GREEN)
    answer_text_A1 = answers_font.render("", True, GREEN)
    answer_text_S1 = answers_font.render("performance", True, GREEN)
    answer_text_D1 = answers_font.render("", True, GREEN)
    #
    screen.blit(title_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.10, 455, 5))
    screen.blit(question_text, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.20, 455, 5))
    screen.blit(question_text1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.25, 455, 5))
    screen.blit(answer_text_W, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.50, 455, 5))
    screen.blit(answer_text_W1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(answer_text_A, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.60, 455, 5))
    screen.blit(answer_text_A1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.65, 455, 5))
    screen.blit(answer_text_S, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.70, 455, 5))
    screen.blit(answer_text_S1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.75, 455, 5))
    screen.blit(answer_text_D, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.80, 455, 5))
    screen.blit(answer_text_D1, (SCREEN_WIDTH * 0.03, SCREEN_HEIGHT * 0.85, 455, 5))
    
#game over screen
def draw_game_over():
    global email_receiver
    
    #
    screen.fill(BLACK)
    #changhe font names to by size based 
    font1 = pygame.font.Font(None, 45)
    font2 = pygame.font.Font(None, 40)
    font3 = pygame.font.Font(None, 30)
    #
    game_over_text = font1.render("GAME OVER", True, GREEN)
    score_text = font1.render(f"Score: {score}", True, GREEN)
    email_text0 = font3.render("Enter your email.", True, WHITE)
    imput_text = font3.render(email_receiver, True, WHITE)        
    email_text1 = font3.render("Then press ENTER to RECEIVE YOUR SCORE.", True, WHITE)
    restart_text = font2.render("Press SPACE to RESTART", True, WHITE)
    
    #
    screen.blit(game_over_text, (SCREEN_WIDTH // 2 - game_over_text.get_width() // 2, SCREEN_HEIGHT * 0.10))
    screen.blit(score_text, (SCREEN_WIDTH // 2 - score_text.get_width() // 2, SCREEN_HEIGHT * 0.25))
    screen.blit(email_text0, (SCREEN_WIDTH // 2 - email_text0.get_width() // 2, SCREEN_HEIGHT * 0.40))
    screen.blit(imput_text, (SCREEN_WIDTH // 2 - imput_text.get_width() // 2, SCREEN_HEIGHT * 0.50))
    pygame.draw.rect(screen, WHITE, (SCREEN_WIDTH * 0.10, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(email_text1, (SCREEN_WIDTH // 2 - email_text1.get_width() // 2, SCREEN_HEIGHT * 0.60))
    screen.blit(restart_text, (SCREEN_WIDTH // 2 - restart_text.get_width() // 2, SCREEN_HEIGHT * 0.70))

#game over screen
def draw_win_game():
    global email_receiver
    
    #
    screen.fill(GREEN)
    #changhe font names to by size based 
    font1 = pygame.font.Font(None, 45)
    font2 = pygame.font.Font(None, 40)
    font3 = pygame.font.Font(None, 30)
    #
    text1 = font1.render("YOU WIN", True, GOLD)
    text2 = font1.render(f"Your score is: {score}", True, GOLD)
    text3 = font3.render("Enter your email.", True, GOLD)
    text4 = font3.render(email_receiver, True, GOLD)        
    text5 = font3.render("Then press ENTER to RECEIVE YOUR SCORE.", True, GOLD)
    text6 = font2.render("Press SPACE to RESTART", True, GOLD)
    
    #
    screen.blit(text1, (SCREEN_WIDTH // 2 - text1.get_width() // 2, SCREEN_HEIGHT * 0.10))
    screen.blit(text2, (SCREEN_WIDTH // 2 - text2.get_width() // 2, SCREEN_HEIGHT * 0.25))
    screen.blit(text3, (SCREEN_WIDTH // 2 - text3.get_width() // 2, SCREEN_HEIGHT * 0.40))
    screen.blit(text4, (SCREEN_WIDTH // 2 - text4.get_width() // 2, SCREEN_HEIGHT * 0.50))
    pygame.draw.rect(screen, WHITE, (SCREEN_WIDTH * 0.10, SCREEN_HEIGHT * 0.55, 455, 5))
    screen.blit(text5, (SCREEN_WIDTH // 2 - text5.get_width() // 2, SCREEN_HEIGHT * 0.60))
    screen.blit(text6, (SCREEN_WIDTH // 2 - text6.get_width() // 2, SCREEN_HEIGHT * 0.70))
    

#main game code loop
#
running = True
clook = pygame.time.Clock()
#
email_receiver = "" # defult eamil adress verable overwirten later
#
while running:
    current_time = pygame.time.get_ticks()
    
    if game_state == PLAYING: #
        play_music(PLAYING) #
    elif game_state == QUESTION: #
        play_music(QUESTION) #
    elif game_state == GAME_OVER: #
        play_music(GAME_OVER) # 
    
    #quit code
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            #movement code
        elif event.type == pygame.KEYDOWN:
            if game_state == PLAYING:
                if event.key == pygame.K_UP: # moveing up,
                    WH_hacker['direction'] = 3
                elif event.key == pygame.K_DOWN: # moveing down,
                    WH_hacker['direction'] = 1
                elif event.key == pygame.K_LEFT: # moveing left,
                    WH_hacker['direction'] = 2
                elif event.key == pygame.K_RIGHT: # moveing right,
                    WH_hacker['direction'] = 0
                    
            if game_state == QUESTION: #
                if event.key == pygame.K_w: #
                    game_state = RESUME
                elif event.key == pygame.K_s: # 
                    game_state = RESUME
                    LIVES -=1
                elif event.key == pygame.K_a: # 
                    game_state = RESUME
                    LIVES -=1
                elif event.key == pygame.K_d: # 
                    game_state = RESUME
                    LIVES -=1
                    
            if game_state == RESUME:
                resume_game()
            
            if game_state == GAME_OVER or GAME_WIN:
                if event.key == pygame.K_BACKSPACE:
                    # Allow deleting characters in email input
                    email_receiver = email_receiver[:-1]
                elif event.key == pygame.K_RETURN:
                    # Send email and restart game on pressing ENTER
                    send_email()
                    reset_game()
                elif event.key == pygame.K_SPACE:
                    # Restart game without sending an email
                    reset_game()
                else:
                    # Add valid characters to email
                    char = event.unicode
                    if char.isprintable():
                        email_receiver += char
                
    # player movment delay code
    if game_state == PLAYING:
        if current_time - last_WH_hacker_move_time > WH_hacker_move_delay: #runs if time has pasted 
            move_WH_hacker() # moves player 
            last_WH_hacker_move_time = current_time # resets time
    # enemy movment delay code
        if current_time - last_BH_move_time > BH_move_delay: #runs if time has pasted 
            for BH in BH_hackers:
                move_BH(BH) # moves enemy 
            last_BH_move_time = current_time # resets time
        
    #maze code
    screen.fill(GOLD) # background
    for y in range(GRID_HEIGHT): # maze walls 
        for x in range(GRID_WIDTH):
            pygame.draw.rect(screen, BLACK, (x*CELL_SIZE, y*CELL_SIZE-550, CELL_SIZE, CELL_SIZE))
            if grid1[y][x] == 1:
                pygame.draw.rect(screen, GREEN, (x*CELL_SIZE, y*CELL_SIZE+50, CELL_SIZE, CELL_SIZE))# maze walls
            elif grid1[y][x] == 0: # dotes, bits
                pygame.draw.circle(screen, WHITE, (x*CELL_SIZE+CELL_SIZE//2, y*CELL_SIZE+CELL_SIZE//2+50), 3)# dotes, bits
        
        #display player
        draw_WH_hacker()

        #display enemy
        for BH in BH_hackers:
            draw_BH(BH)
        #display score
        score_text = font.render(f"Bits collected: {score}", True, WHITE)
        screen.blit(score_text,(SCREEN_WIDTH * 0.05, SCREEN_HEIGHT * 0.025))
        #
        LIVES_text = font.render(f"Proxies: {LIVES}", True, WHITE)
        screen.blit(LIVES_text,(SCREEN_WIDTH * 0.75, SCREEN_HEIGHT * 0.025))
        
        #check for colistion with enemy
        for BH in BH_hackers:
            if WH_hacker['x'] == BH['x'] and WH_hacker['y'] == BH['y']:
                game_state = QUESTION
            elif game_state == QUESTION:
                if question_loop == 1:
                    question_number = random.randint(1, 20)
                if question_number == 1:
                    draw_question1()
                    question_loop = 2 
                elif question_number == 2:
                    draw_question2()
                    question_loop = 2 
                elif question_number == 3:
                    draw_question3()
                    question_loop = 2 
                elif question_number == 4:
                    draw_question4()
                    question_loop = 2 
                elif question_number == 5:
                    draw_question5()
                    question_loop = 2 
                elif question_number == 6:
                    draw_question6()
                    question_loop = 2 
                elif question_number == 7:
                    draw_question7()
                    question_loop = 2 
                elif question_number == 8:
                    draw_question8()
                    question_loop = 2 
                elif question_number == 9:
                    draw_question9()
                    question_loop = 2 
                elif question_number == 10:
                    draw_question10()
                    question_loop = 2 
                elif question_number == 11:
                    draw_question11()
                    question_loop = 2 
                elif question_number == 12: 
                    draw_question12()
                    question_loop = 2 
                elif question_number == 13:
                    draw_question13()
                    question_loop = 2 
                elif question_number == 14:
                    draw_question14()
                    question_loop = 2 
                elif question_number == 15:
                    draw_question15()
                    question_loop = 2 
                elif question_number == 16:
                    draw_question16()
                    question_loop = 2 
                elif question_number == 17:
                    draw_question17()
                    question_loop = 2 
                elif question_number == 18:
                    draw_question18()
                    question_loop = 2 
                elif question_number == 19:
                    draw_question19()
                    question_loop = 2 
                elif question_number == 20:
                    draw_question20()
                    question_loop = 2 
             
        #kill code
            if LIVES == 0:
                game_state = GAME_OVER
            if game_state == GAME_OVER:
             draw_game_over()
        #
            if score == 1070:
                game_state = GAME_WIN
            if game_state == GAME_WIN:
             draw_win_game()

    # update the display
    pygame.display.flip()

    #cap the fram rate
    clock.tick(60)

pygame.quit()

sys.exit()
        
        